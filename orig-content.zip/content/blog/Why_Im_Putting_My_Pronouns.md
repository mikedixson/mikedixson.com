---
title: "Why I’m putting my pronouns in my signature/everywhere and you should too"
date: 2021-08-14T14:46:10+06:00
description: "It’s a small act that you can do, but it’s a very human act. I implore you to put your pronouns everywhere."
type: "featured"
image: "/images/featured-post/Beige Modern Illustration Women's Rights Poster-socials-notext.png"
categories: 
  - "Valuable Idea"
tags:
  - "society"
  - "betterness"
---


A post on tiktok where a young lad responded to a commenter “Why do you put your pronouns when you’re cis gender” made way too much sense.

The tiktoker responded
> “To normalise it for everyone so they feel more comfortable putting theirs too”

It’s such a seemingly small act but actually if everyone in your work place, friend group, world, puts their pronouns it just becomes so normalized and makes it more comfortable for everyone.

More and more there are options to specify your pronouns on your web profiles now, Instagram now has a field in it’s profile section. And you can always add simple text in to any bio: Pronouns: he/him

It’s a small act that you can do, but it’s a very human act. I implore you to put your pronouns everywhere.