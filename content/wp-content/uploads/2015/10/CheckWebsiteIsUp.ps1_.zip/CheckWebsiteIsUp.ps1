#Initialising
$webClient = new-object System.Net.WebClient
$webClient.Headers.Add("user-agent", "PowerShell Script")


#Variables to modify
$output = "" #Define output variable
$serviceName = "confluence" #Short windows service name
$smtpServerName = "smtp.website.com" #SMTP Server name
$fromEmailAddress = "servername@website.com" #Email address for mail to come from/reply address
$stringToCheckFor = "The service is unavailable" #String to check for. Note that this will be searched for with wildcards either side
$startTime = get-date
$output = $webClient.DownloadString("http://www.website.com/") #Modify this url to be the url you want to test
$endTime = get-date

#Main workload
#The below checks for the string "The service is unavailable" from your website and if found forcefully restarts the defined service
if ($output -And $output -notlike "*$stringToCheckFor*") {
    "Site Up`t`t" + $startTime.DateTime + "`t`t" + ($endTime - $startTime).TotalSeconds + " seconds"
} else {
    "Fail`t`t" + $startTime.DateTime + "`t`t" + ($endTime - $startTime).TotalSeconds + " seconds"
    stop-service $serviceName -force
    "Stop Service Command Sent"
    $svc = Get-Service $serviceName
    $svc.WaitForStatus('Stopped','00:05:00') #Waits for service to enter stopped state or 5 mins has passed, whichever is first
    get-service $serviceName | where-object {$_.Status -eq "Stopped"} | restart-service #Belt and braces but only restarts the service if it's stopped.
    $svc.WaitForStatus('Running','00:01:00') #Waits for service to enter Running state or 1 minute to pass, whichever is first
    Send-MailMessage -From “intranet@rave.ac.uk” -To “$fromEmailAddress” -SmtpServer “$smtpServerName” -Subject "$serviceName Service Restarted" -Body "$serviceName Service Restarted" #Sends an email alert that the service was restarted
}